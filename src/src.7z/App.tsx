import './App.css'
import HomeComp from './screen/HomeScreen'

function App() {

  return (
    <>
    <HomeComp/>
      
    </>
  )
}

export default App
